export const selectEl = (selector) => document.querySelector(selector);
